import os, json, time
from dmw_validator.utils import resolve_table_field, extract_logic
from dmw_validator.ai_core import _run_batch, load_llm

def run_ai_extensions(issues, out_dir="outputs/job1/ai", model="light", prompt_profile="business"):
    os.makedirs(out_dir, exist_ok=True)
    if not issues:
        print("ℹ️ No issues detected, AI extensions skipped.")
        return []

    llm = load_llm(model)
    results = []
    start = time.time()
    print(f"⚙️ AI validation (row-by-row) started… {len(issues)} rows using model={model}, profile={prompt_profile}")

    for idx, rec in enumerate(issues, 1):
        table, field = resolve_table_field(rec)
        logic = extract_logic(rec)
        parsed = _run_batch([rec], offset=idx-1, focus="Check logic", llm=llm, prompt_profile=prompt_profile)
        p = parsed[0] if parsed else {}

        results.append({
            "Target Table": table,
            "Target Field": field,
            "Logic": logic,
            "AI_Judgement": p.get("judgement", "Unclear"),
            "AI_Explanation": p.get("explanation", "No explicit output from model"),
            "AI_Suggested_Followup": p.get("suggested_followup", "Review transformation manually")
        })

    with open(os.path.join(out_dir, "logic_quality.json"), "w") as f:
        json.dump(results, f, indent=2)

    print(f"✅ AI validation complete → {out_dir} ({len(results)} rows, {time.time()-start:.1f}s)")
    return results
